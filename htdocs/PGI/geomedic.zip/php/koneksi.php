<?php
$mysqli = mysqli_connect("localhost","root","","geomedic")or die("gagal");
?>
