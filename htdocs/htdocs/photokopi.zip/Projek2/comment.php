<html>
	<head>
		<style>
			.container-comment{
				height:500px;
				width: 800px;
				border: 1.7px solid #C4CDE0;
				margin-left:240px;
				margin-top:50px;
				
				
				}
				.photo-kiri{
				height: 100%;
				width: 70%;
				background-color:blue;
				float:left;	
				}
				.comment-kanan{
				height: 100%;
				width: 30%;
				background-color:white;
				float:left;
				}
				.photo2{
					border-radius:100%;
					background-size:cover;
					margin:20px;
					float:left;
				}
				.user2{
					float:left;
					margin-top:40px;
				}
				.comment-kanan hr{
					margin-top:150px;
				}
				.komentar{
					width:100%;
					min-height:500px;
					margin:0px;
					overflow:scroll; 
					word-wrap:break-word;
				}
		</style>
		
	</head>
	
	<body>
		<div class="container-comment">
			<div class="photo-kiri">
				<img src="img/macan.jpg" width="100%" height="100%"  />
			</div>	
			<div class="comment-kanan">
				<img class="photo2" src="img/kelinci.jpg" width="60px" height="60px"  />
				<div class="user2"> USER</div>
				<hr />
				<div class="komentar">
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll<br />
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll<br />
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
					jikjijijlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
				</div>
				
			</div>	
		</div>
		
	</body>
</html>